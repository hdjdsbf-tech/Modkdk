#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/ui/GeodeUI.hpp>
#include <matjson.hpp>
#include <filesystem>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>

using namespace geode::prelude;

struct MacroAction {
    int frameOffset = 0;
    double xPos = 0.0;
    double yPos = 0.0;
    double yVel = 0.0;
    float rotation = 0.0f;
    bool down = true;
    int button = 1;
    bool isPlayer2 = false;
    int frameWindow = 0;
};

struct MacroData {
    std::string name = "macro_1";
    int levelID = 0;
    double startX = 0.0;
    double startY = 0.0;
    double startYVel = 0.0;
    float startRot = 0.0f;
    bool analyzed = false;
    std::vector<MacroAction> actions;

    void clear() {
        actions.clear();
        startX = 0.0;
        startY = 0.0;
        startYVel = 0.0;
        startRot = 0.0f;
        analyzed = false;
    }
};

enum class AnalysisSpeed {
    Full = 0,
    Fast = 1,
    MegaFast = 2
};

struct ModGlobals {
    bool isRecording = false;
    bool isPlaying = false;
    bool isWaitingForSync = false;
    bool isSyncedAndLocked = false;
    int currentTick = 0;
    int syncBaseTick = 0;
    size_t nextActionIdx = 0;

    bool speedhackEnabled = false;
    float speedhackValue = 1.0f;

    AnalysisSpeed analysisMode = AnalysisSpeed::Full;
    bool isAnalyzing = false;
    float analysisProgress = 0.0f;
    size_t analysisCursor = 0;

    int count1F = 0;
    int count2F = 0;
    int count3F = 0;
    int countWide = 0;
    int lastWindow = 0;
    bool lastWasRelease = false;

    MacroData macro;

    std::filesystem::path getMacrosFolder() {
        auto dir = Mod::get()->getSaveDir() / "macros";
        if (!std::filesystem::exists(dir)) {
            std::filesystem::create_directories(dir);
        }
        return dir;
    }

    bool saveToFile(const std::string& filename) {
        matjson::Value root = matjson::Object();
        root["name"] = filename;
        root["levelID"] = macro.levelID;
        root["startX"] = macro.startX;
        root["startY"] = macro.startY;
        root["startYVel"] = macro.startYVel;
        root["startRot"] = (double)macro.startRot;
        root["analyzed"] = macro.analyzed;

        matjson::Array arr;
        for (const auto& act : macro.actions) {
            matjson::Value item = matjson::Object();
            item["f"] = act.frameOffset;
            item["x"] = act.xPos;
            item["y"] = act.yPos;
            item["yv"] = act.yVel;
            item["r"] = (double)act.rotation;
            item["d"] = act.down;
            item["b"] = act.button;
            item["p2"] = act.isPlayer2;
            item["fw"] = act.frameWindow;
            arr.push_back(item);
        }
        root["actions"] = arr;

        auto path = getMacrosFolder() / (filename + ".json");
        std::ofstream out(path);
        if (!out.is_open()) return false;
        out << root.dump(matjson::NO_INDENTATION);
        out.close();
        macro.name = filename;
        return true;
    }

    bool loadFromFile(const std::string& filename) {
        auto path = getMacrosFolder() / (filename + ".json");
        if (!std::filesystem::exists(path)) return false;

        std::ifstream in(path);
        if (!in.is_open()) return false;
        std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        in.close();

        auto parsed = matjson::parse(content);
        if (!parsed.is_ok()) return false;
        auto root = parsed.unwrap();

        macro.clear();
        macro.name = root["name"].as_string().unwrapOr(filename);
        macro.levelID = (int)root["levelID"].as_int().unwrapOr(0);
        macro.startX = root["startX"].as_double().unwrapOr(0.0);
        macro.startY = root["startY"].as_double().unwrapOr(0.0);
        macro.startYVel = root["startYVel"].as_double().unwrapOr(0.0);
        macro.startRot = (float)root["startRot"].as_double().unwrapOr(0.0);
        macro.analyzed = root["analyzed"].as_bool().unwrapOr(false);

        if (root.contains("actions") && root["actions"].is_array()) {
            for (const auto& item : root["actions"].as_array().unwrap()) {
                MacroAction act;
                act.frameOffset = (int)item["f"].as_int().unwrapOr(0);
                act.xPos = item["x"].as_double().unwrapOr(0.0);
                act.yPos = item["y"].as_double().unwrapOr(0.0);
                act.yVel = item["yv"].as_double().unwrapOr(0.0);
                act.rotation = (float)item["r"].as_double().unwrapOr(0.0);
                act.down = item["d"].as_bool().unwrapOr(true);
                act.button = (int)item["b"].as_int().unwrapOr(1);
                act.isPlayer2 = item["p2"].as_bool().unwrapOr(false);
                act.frameWindow = (int)item["fw"].as_int().unwrapOr(0);
                macro.actions.push_back(act);
            }
        }
        return true;
    }
};

static ModGlobals g_mod;

class $modify(SpeedhackScheduler, CCScheduler) {
    void update(float dt) {
        if (g_mod.speedhackEnabled && PlayLayer::get() != nullptr) {
            dt *= g_mod.speedhackValue;
        }
        CCScheduler::update(dt);
    }
};

static int computeActionFrameWindow(PlayLayer* pl, const MacroAction& act, size_t idx, const std::vector<MacroAction>& all) {
    double minGapTicks = 999.0;
    if (idx > 0) {
        minGapTicks = std::min(minGapTicks, (double)(act.frameOffset - all[idx - 1].frameOffset));
    }
    if (idx + 1 < all.size()) {
        minGapTicks = std::min(minGapTicks, (double)(all[idx + 1].frameOffset - act.frameOffset));
    }

    double hazardSeverity = 0.0;
    if (pl && pl->m_objects) {
        CCObject* obj = nullptr;
        CCARRAY_FOREACH(pl->m_objects, obj) {
            auto go = typeinfo_cast<GameObject*>(obj);
            if (!go) continue;
            double dx = std::abs(go->getPositionX() - act.xPos);
            double dy = std::abs(go->getPositionY() - act.yPos);
            if (dx < 95.0 && dy < 95.0) {
                if (go->m_objectType == GameObjectType::Hazard || 
                    go->m_objectType == GameObjectType::AnimatedHazard ||
                    go->m_objectType == GameObjectType::Solid) {
                    double dist = std::sqrt(dx * dx + dy * dy);
                    if (dist < 42.0) hazardSeverity += 3.5;
                    else if (dist < 68.0) hazardSeverity += 1.8;
                }
            }
        }
    }

    double velFactor = std::abs(act.yVel) / 10.5;
    double tightnessScore = hazardSeverity + velFactor + (12.0 / std::max(1.0, minGapTicks));

    if (!act.down) {
        tightnessScore *= 0.85;
    }

    if (tightnessScore >= 4.2 || minGapTicks <= 2.0) return 1;
    if (tightnessScore >= 2.8 || minGapTicks <= 4.0) return 2;
    if (tightnessScore >= 1.7 || minGapTicks <= 7.0) return 3;
    if (tightnessScore >= 1.1) return 4;
    if (tightnessScore >= 0.7) return 5;
    return 6;
}

static bool s_isInternalMacroClick = false;

class $modify(MacroInputLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        auto pl = PlayLayer::get();
        if (!pl || this != static_cast<GJBaseGameLayer*>(pl)) {
            GJBaseGameLayer::handleButton(down, button, isPlayer1);
            return;
        }

        if (g_mod.isPlaying && g_mod.isSyncedAndLocked && !s_isInternalMacroClick) {
            if (Mod::get()->getSettingValue<bool>("lock-input-on-sync")) {
                return;
            }
        }

        GJBaseGameLayer::handleButton(down, button, isPlayer1);

        if (g_mod.isRecording && pl->m_player1) {
            MacroAction act;
            act.frameOffset = g_mod.currentTick - g_mod.syncBaseTick;
            act.xPos = pl->m_player1->m_position.x;
            act.yPos = pl->m_player1->m_position.y;
            act.yVel = pl->m_player1->m_yVelocity;
            act.rotation = pl->m_player1->getRotation();
            act.down = down;
            act.button = button;
            act.isPlayer2 = !isPlayer1;
            act.frameWindow = 0;
            g_mod.macro.actions.push_back(act);
        }
    }
};

class $modify(FramePlayLayer, PlayLayer) {
    struct Fields {
        CCNode* hudContainer = nullptr;
        CCScale9Sprite* hudBg = nullptr;
        CCLabelBMFont* titleLbl = nullptr;
        CCLabelBMFont* syncStateLbl = nullptr;
        CCLabelBMFont* currentWindowLbl = nullptr;
        CCLabelBMFont* statsCounterLbl = nullptr;
        CCDrawNode* indicatorDot = nullptr;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

        createPlayMacroHUD();
        updatePlayMacroHUD();

        return true;
    }

    void createPlayMacroHUD() {
        auto winSize = CCDirector::sharedDirector()->getWinSize();

        auto container = CCNode::create();
        container->setPosition({ 14.f, winSize.height - 14.f });
        container->setAnchorPoint({ 0.f, 1.f });
        container->setZOrder(9999);

        auto bg = CCScale9Sprite::create("square02b_001.png");
        bg->setColor({ 12, 16, 28 });
        bg->setOpacity(205);
        bg->setContentSize({ 185.f, 68.f });
        bg->setPosition({ 92.5f, -34.f });
        container->addChild(bg);
        m_fields->hudBg = bg;

        auto border = CCDrawNode::create();
        CCPoint rect[4] = {
            ccp(0.f, -68.f),
            ccp(185.f, -68.f),
            ccp(185.f, 0.f),
            ccp(0.f, 0.f)
        };
        ccColor4F fill = { 0.f, 0.f, 0.f, 0.f };
        ccColor4F stroke = { 0.2f, 0.85f, 1.0f, 0.85f };
        border->drawPolygon(rect, 4, fill, 1.2f, stroke);
        container->addChild(border);

        auto dot = CCDrawNode::create();
        dot->drawDot(ccp(12.f, -13.f), 4.5f, ccc4f(0.f, 1.f, 0.5f, 1.f));
        container->addChild(dot);
        m_fields->indicatorDot = dot;

        auto title = CCLabelBMFont::create("PLAY MACRO [HUD]", "bigFont.fnt");
        title->setScale(0.32f);
        title->setAnchorPoint({ 0.f, 0.5f });
        title->setPosition({ 22.f, -13.f });
        title->setColor({ 120, 235, 255 });
        container->addChild(title);
        m_fields->titleLbl = title;

        auto syncLbl = CCLabelBMFont::create("SYNC: READY", "chatFont.fnt");
        syncLbl->setScale(0.55f);
        syncLbl->setAnchorPoint({ 0.f, 0.5f });
        syncLbl->setPosition({ 10.f, -29.f });
        syncLbl->setColor({ 255, 230, 100 });
        container->addChild(syncLbl);
        m_fields->syncStateLbl = syncLbl;

        auto curWin = CCLabelBMFont::create("Window: --", "goldFont.fnt");
        curWin->setScale(0.42f);
        curWin->setAnchorPoint({ 0.f, 0.5f });
        curWin->setPosition({ 10.f, -44.f });
        container->addChild(curWin);
        m_fields->currentWindowLbl = curWin;

        auto stats = CCLabelBMFont::create("1F(FP): 0 | 2F: 0 | 3F: 0 | 4F+: 0", "chatFont.fnt");
        stats->setScale(0.50f);
        stats->setAnchorPoint({ 0.f, 0.5f });
        stats->setPosition({ 10.f, -58.f });
        stats->setColor({ 210, 220, 235 });
        container->addChild(stats);
        m_fields->statsCounterLbl = stats;

        container->setVisible(g_mod.isPlaying);

        if (this->m_uiLayer) {
            this->m_uiLayer->addChild(container);
        } else {
            this->addChild(container);
        }
        m_fields->hudContainer = container;
    }

    void updatePlayMacroHUD() {
        if (!m_fields->hudContainer) return;

        if (!g_mod.isPlaying) {
            m_fields->hudContainer->setVisible(false);
            return;
        }

        m_fields->hudContainer->setVisible(true);

        if (g_mod.isWaitingForSync) {
            double curX = this->m_player1 ? this->m_player1->m_position.x : 0.0;
            m_fields->syncStateLbl->setString(
                fmt::format("WAIT SYNC (X: {} / {})", (int)curX, (int)g_mod.macro.startX).c_str()
            );
            m_fields->syncStateLbl->setColor({ 255, 195, 50 });
        } else if (g_mod.isSyncedAndLocked) {
            m_fields->syncStateLbl->setString("SYNCED [SCREEN LOCKED]");
            m_fields->syncStateLbl->setColor({ 80, 255, 140 });
        } else {
            m_fields->syncStateLbl->setString("MACRO FINISHED");
            m_fields->syncStateLbl->setColor({ 180, 180, 200 });
        }

        if (!g_mod.macro.analyzed) {
            m_fields->currentWindowLbl->setString("Window: Not Analyzed");
            m_fields->currentWindowLbl->setColor({ 200, 200, 200 });
        } else if (g_mod.lastWindow == 0) {
            m_fields->currentWindowLbl->setString("Window: Waiting click...");
            m_fields->currentWindowLbl->setColor({ 220, 220, 220 });
        } else if (g_mod.lastWindow == 1) {
            m_fields->currentWindowLbl->setString(
                fmt::format("1F FRAME PERFECT! {}", g_mod.lastWasRelease ? "(REL)" : "(CLK)").c_str()
            );
            m_fields->currentWindowLbl->setColor({ 255, 65, 90 });
        } else if (g_mod.lastWindow <= 3) {
            m_fields->currentWindowLbl->setString(
                fmt::format("{}F Tight Window {}", g_mod.lastWindow, g_mod.lastWasRelease ? "(REL)" : "(CLK)").c_str()
            );
            m_fields->currentWindowLbl->setColor({ 255, 215, 70 });
        } else {
            m_fields->currentWindowLbl->setString(
                fmt::format("{}F Wide Window {}", g_mod.lastWindow, g_mod.lastWasRelease ? "(REL)" : "(CLK)").c_str()
            );
            m_fields->currentWindowLbl->setColor({ 105, 255, 145 });
        }

        m_fields->statsCounterLbl->setString(
            fmt::format("1F(FP): {} | 2F: {} | 3F: {} | Wide: {}",
                g_mod.count1F, g_mod.count2F, g_mod.count3F, g_mod.countWide).c_str()
        );
    }

    void resetLevel() {
        PlayLayer::resetLevel();

        g_mod.currentTick = 0;
        g_mod.nextActionIdx = 0;
        g_mod.count1F = 0;
        g_mod.count2F = 0;
        g_mod.count3F = 0;
        g_mod.countWide = 0;
        g_mod.lastWindow = 0;

        if (this->m_player1) {
            double currentX = this->m_player1->m_position.x;

            if (g_mod.isRecording) {
                g_mod.macro.clear();
                g_mod.macro.levelID = this->m_level ? this->m_level->m_levelID.value() : 0;
                g_mod.macro.startX = currentX;
                g_mod.macro.startY = this->m_player1->m_position.y;
                g_mod.macro.startYVel = this->m_player1->m_yVelocity;
                g_mod.macro.startRot = this->m_player1->getRotation();
                g_mod.syncBaseTick = 0;
            }

            if (g_mod.isPlaying && !g_mod.macro.actions.empty()) {
                if (currentX < g_mod.macro.startX - 1.5) {
                    g_mod.isWaitingForSync = true;
                    g_mod.isSyncedAndLocked = false;
                } else {
                    g_mod.isWaitingForSync = false;
                    g_mod.isSyncedAndLocked = true;
                    g_mod.syncBaseTick = 0;
                }
            } else {
                g_mod.isWaitingForSync = false;
                g_mod.isSyncedAndLocked = false;
            }
        }

        updatePlayMacroHUD();
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);

        if (!this->m_player1 || this->m_isPaused || this->m_player1->m_isDead) {
            return;
        }

        g_mod.currentTick++;
        double curX = this->m_player1->m_position.x;

        if (g_mod.isPlaying && !g_mod.macro.actions.empty()) {
            if (g_mod.isWaitingForSync) {
                if (curX >= g_mod.macro.startX) {
                    g_mod.isWaitingForSync = false;
                    g_mod.isSyncedAndLocked = true;
                    g_mod.syncBaseTick = g_mod.currentTick;
                    g_mod.nextActionIdx = 0;

                    this->m_player1->m_position.x = g_mod.macro.startX;
                    this->m_player1->m_position.y = g_mod.macro.startY;
                    this->m_player1->m_yVelocity = g_mod.macro.startYVel;
                    this->m_player1->setRotation(g_mod.macro.startRot);
                } else {
                    updatePlayMacroHUD();
                    return;
                }
            }

            if (g_mod.isSyncedAndLocked) {
                int relativeTick = g_mod.currentTick - g_mod.syncBaseTick;

                while (g_mod.nextActionIdx < g_mod.macro.actions.size()) {
                    const auto& act = g_mod.macro.actions[g_mod.nextActionIdx];

                    if (relativeTick >= act.frameOffset || curX >= act.xPos - 0.05) {
                        if (Mod::get()->getSettingValue<bool>("strict-physics-sync")) {
                            this->m_player1->m_position.x = act.xPos;
                            this->m_player1->m_position.y = act.yPos;
                            this->m_player1->m_yVelocity = act.yVel;
                        }

                        s_isInternalMacroClick = true;
                        this->handleButton(act.down, act.button, !act.isPlayer2);
                        s_isInternalMacroClick = false;

                        int fw = act.frameWindow;
                        if (!g_mod.macro.analyzed || fw <= 0) {
                            fw = computeActionFrameWindow(this, act, g_mod.nextActionIdx, g_mod.macro.actions);
                        }
                        g_mod.lastWindow = fw;
                        g_mod.lastWasRelease = !act.down;

                        if (act.down) {
                            if (fw == 1) g_mod.count1F++;
                            else if (fw == 2) g_mod.count2F++;
                            else if (fw == 3) g_mod.count3F++;
                            else g_mod.countWide++;
                        }

                        g_mod.nextActionIdx++;
                    } else {
                        break;
                    }
                }

                if (g_mod.nextActionIdx >= g_mod.macro.actions.size()) {
                    g_mod.isSyncedAndLocked = false;
                }
            }

            updatePlayMacroHUD();
        } else if (m_fields->hudContainer && m_fields->hudContainer->isVisible()) {
            m_fields->hudContainer->setVisible(false);
        }
    }
};

class FrameAnalyzerPopup : public geode::Popup<> {
protected:
    CCLabelBMFont* m_modeLabel = nullptr;
    CCLabelBMFont* m_statusLabel = nullptr;
    CCLabelBMFont* m_percentLabel = nullptr;
    CCLabelBMFont* m_liveResultLabel = nullptr;
    CCDrawNode* m_scannerGraph = nullptr;
    float m_scanPhase = 0.0f;
    int m_found1F = 0;
    int m_found2F = 0;
    int m_found3F = 0;
    int m_foundWide = 0;

    bool setup() override {
        this->setTitle("Frame Window Analyzer");

        auto winSize = m_mainLayer->getContentSize();

        m_modeLabel = CCLabelBMFont::create(getModeTitle().c_str(), "goldFont.fnt");
        m_modeLabel->setScale(0.55f);
        m_modeLabel->setPosition({ winSize.width / 2.f, winSize.height - 46.f });
        m_mainLayer->addChild(m_modeLabel);

        auto modeMenu = CCMenu::create();
        modeMenu->setPosition({ winSize.width / 2.f, winSize.height - 74.f });

        auto btnFull = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Full", 65, true, "bigFont.fnt", "GJ_button_01.png", 26.f, 0.45f),
            this, menu_selector(FrameAnalyzerPopup::onSelectMode)
        );
        btnFull->setTag(0);

        auto btnFast = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Fast", 65, true, "bigFont.fnt", "GJ_button_02.png", 26.f, 0.45f),
            this, menu_selector(FrameAnalyzerPopup::onSelectMode)
        );
        btnFast->setTag(1);

        auto btnMega = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Mega Fast", 85, true, "bigFont.fnt", "GJ_button_03.png", 26.f, 0.45f),
            this, menu_selector(FrameAnalyzerPopup::onSelectMode)
        );
        btnMega->setTag(2);

        modeMenu->addChild(btnFull);
        modeMenu->addChild(btnFast);
        modeMenu->addChild(btnMega);
        modeMenu->alignItemsHorizontallyWithPadding(8.f);
        m_mainLayer->addChild(modeMenu);

        m_scannerGraph = CCDrawNode::create();
        m_scannerGraph->setPosition({ winSize.width / 2.f - 130.f, winSize.height / 2.f - 22.f });
        m_mainLayer->addChild(m_scannerGraph);

        m_percentLabel = CCLabelBMFont::create("0%", "bigFont.fnt");
        m_percentLabel->setScale(0.55f);
        m_percentLabel->setPosition({ winSize.width / 2.f, winSize.height / 2.f + 12.f });
        m_mainLayer->addChild(m_percentLabel);

        m_statusLabel = CCLabelBMFont::create("Press [Start Scan] to analyze macro timings", "chatFont.fnt");
        m_statusLabel->setScale(0.62f);
        m_statusLabel->setPosition({ winSize.width / 2.f, 68.f });
        m_statusLabel->setColor({ 180, 235, 255 });
        m_mainLayer->addChild(m_statusLabel);

        m_liveResultLabel = CCLabelBMFont::create("1F (Frame Perfect): 0  |  2F: 0  |  3F: 0  |  Wide: 0", "chatFont.fnt");
        m_liveResultLabel->setScale(0.60f);
        m_liveResultLabel->setPosition({ winSize.width / 2.f, 48.f });
        m_liveResultLabel->setColor({ 255, 220, 110 });
        m_mainLayer->addChild(m_liveResultLabel);

        auto startMenu = CCMenu::create();
        startMenu->setPosition({ winSize.width / 2.f, 22.f });
        auto startBtn = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Start Analysis", 120, true, "goldFont.fnt", "GJ_button_01.png", 30.f, 0.6f),
            this, menu_selector(FrameAnalyzerPopup::onStartAnalysis)
        );
        startMenu->addChild(startBtn);
        m_mainLayer->addChild(startMenu);

        drawVisualScanner();
        this->schedule(schedule_selector(FrameAnalyzerPopup::updateAnalysisTick), 0.016f);

        return true;
    }

    std::string getModeTitle() {
        switch (g_mod.analysisMode) {
            case AnalysisSpeed::Full: return "Mode: FULL (Deep Frame-by-Frame Scan)";
            case AnalysisSpeed::Fast: return "Mode: FAST (Accelerated Trajectory Scan)";
            case AnalysisSpeed::MegaFast: return "Mode: MEGA FAST (Instant Quantum Scan)";
        }
        return "Mode: FULL";
    }

    void onSelectMode(CCObject* sender) {
        if (g_mod.isAnalyzing) return;
        int tag = sender->getTag();
        g_mod.analysisMode = static_cast<AnalysisSpeed>(tag);
        Mod::get()->setSettingValue<int>("analysis-mode", tag);
        m_modeLabel->setString(getModeTitle().c_str());
    }

    void onStartAnalysis(CCObject*) {
        if (g_mod.macro.actions.empty()) {
            FLAlertLayer::create("FrameMmeVjopy", "Macro is empty! Record or load a macro first.", "OK")->show();
            return;
        }
        g_mod.isAnalyzing = true;
        g_mod.analysisCursor = 0;
        g_mod.analysisProgress = 0.0f;
        m_found1F = m_found2F = m_found3F = m_foundWide = 0;
        m_statusLabel->setString("Scanning level hitboxes & frame windows...");
    }

    void updateAnalysisTick(float dt) {
        m_scanPhase += dt * 7.5f;

        if (g_mod.isAnalyzing) {
            size_t total = g_mod.macro.actions.size();
            if (total == 0) {
                g_mod.isAnalyzing = false;
                return;
            }

            size_t stepPerTick = 1;
            if (g_mod.analysisMode == AnalysisSpeed::Full) {
                stepPerTick = std::max<size_t>(1, total / 90);
            } else if (g_mod.analysisMode == AnalysisSpeed::Fast) {
                stepPerTick = std::max<size_t>(2, total / 30);
            } else {
                stepPerTick = std::max<size_t>(10, total / 6);
            }

            auto pl = PlayLayer::get();
            for (size_t s = 0; s < stepPerTick && g_mod.analysisCursor < total; ++s) {
                auto& act = g_mod.macro.actions[g_mod.analysisCursor];
                act.frameWindow = computeActionFrameWindow(pl, act, g_mod.analysisCursor, g_mod.macro.actions);

                if (act.down) {
                    if (act.frameWindow == 1) m_found1F++;
                    else if (act.frameWindow == 2) m_found2F++;
                    else if (act.frameWindow == 3) m_found3F++;
                    else m_foundWide++;
                }
                g_mod.analysisCursor++;
            }

            g_mod.analysisProgress = (float)g_mod.analysisCursor / (float)total;
            int pct = std::min(100, (int)(g_mod.analysisProgress * 100.0f));
            m_percentLabel->setString(fmt::format("{}%", pct).c_str());

            if (g_mod.analysisCursor > 0 && g_mod.analysisCursor <= total) {
                const auto& lastAct = g_mod.macro.actions[g_mod.analysisCursor - 1];
                m_statusLabel->setString(
                    fmt::format("Analyzing tick #{} (X: {:.1f}) -> {}F Window",
                        lastAct.frameOffset, lastAct.xPos, lastAct.frameWindow).c_str()
                );
            }

            m_liveResultLabel->setString(
                fmt::format("1F (Frame Perfect): {}  |  2F: {}  |  3F: {}  |  Wide: {}",
                    m_found1F, m_found2F, m_found3F, m_foundWide).c_str()
            );

            if (g_mod.analysisCursor >= total) {
                g_mod.isAnalyzing = false;
                g_mod.macro.analyzed = true;
                m_statusLabel->setString("Analysis Complete! Frame Windows saved to Macro.");
                m_statusLabel->setColor({ 90, 255, 130 });
            }
        }

        drawVisualScanner();
    }

    void drawVisualScanner() {
        if (!m_scannerGraph) return;
        m_scannerGraph->clear();

        float width = 260.f;
        float height = 56.f;

        CCPoint bgRect[4] = {
            ccp(0, 0), ccp(width, 0), ccp(width, height), ccp(0, height)
        };
        m_scannerGraph->drawPolygon(bgRect, 4, ccc4f(0.04f, 0.07f, 0.12f, 0.92f), 1.2f, ccc4f(0.2f, 0.7f, 1.0f, 0.8f));

        float progW = width * g_mod.analysisProgress;
        if (progW > 1.f) {
            CCPoint pRect[4] = {
                ccp(0, 0), ccp(progW, 0), ccp(progW, 6.f), ccp(0, 6.f)
            };
            m_scannerGraph->drawPolygon(pRect, 4, ccc4f(0.1f, 0.95f, 0.55f, 0.9f), 0.f, ccc4f(0, 0, 0, 0));
        }

        size_t total = g_mod.macro.actions.size();
        int bars = 36;
        float barStep = (width - 12.f) / (float)bars;

        for (int i = 0; i < bars; ++i) {
            float x = 6.f + i * barStep;
            float wave = std::sin(m_scanPhase + i * 0.35f) * 0.5f + 0.5f;
            float barH = 10.f + wave * 28.f;
            ccColor4F col = ccc4f(0.2f, 0.6f, 0.95f, 0.45f);

            if (total > 0) {
                size_t mappedIdx = (i * total) / bars;
                if (mappedIdx < g_mod.analysisCursor && mappedIdx < total) {
                    int fw = g_mod.macro.actions[mappedIdx].frameWindow;
                    if (fw == 1) {
                        barH = 42.f;
                        col = ccc4f(1.0f, 0.22f, 0.35f, 0.95f);
                    } else if (fw <= 3) {
                        barH = 29.f;
                        col = ccc4f(1.0f, 0.85f, 0.2f, 0.9f);
                    } else {
                        barH = 18.f;
                        col = ccc4f(0.25f, 0.95f, 0.5f, 0.85f);
                    }
                }
            }

            m_scannerGraph->drawSegment(ccp(x, 9.f), ccp(x, 9.f + barH), 2.2f, col);
        }
    }

public:
    static FrameAnalyzerPopup* create() {
        auto ret = new FrameAnalyzerPopup();
        if (ret && ret->initAnchored(340.f, 225.f, "GJ_square02.png")) {
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

class FrameMainPopup : public geode::Popup<> {
protected:
    CCLabelBMFont* m_stateInfoLbl = nullptr;
    CCLabelBMFont* m_speedLbl = nullptr;
    CCLabelBMFont* m_macroSummaryLbl = nullptr;
    geode::TextInput* m_fileInput = nullptr;

    bool setup() override {
        this->setTitle("FrameMmeVjopy v1.2 (ARM64)");
        auto winSize = m_mainLayer->getContentSize();

        m_stateInfoLbl = CCLabelBMFont::create("", "goldFont.fnt");
        m_stateInfoLbl->setScale(0.45f);
        m_stateInfoLbl->setPosition({ winSize.width / 2.f, winSize.height - 44.f });
        m_mainLayer->addChild(m_stateInfoLbl);

        m_macroSummaryLbl = CCLabelBMFont::create("", "chatFont.fnt");
        m_macroSummaryLbl->setScale(0.58f);
        m_macroSummaryLbl->setPosition({ winSize.width / 2.f, winSize.height - 62.f });
        m_macroSummaryLbl->setColor({ 185, 230, 255 });
        m_mainLayer->addChild(m_macroSummaryLbl);

        auto ctrlMenu = CCMenu::create();
        ctrlMenu->setPosition({ winSize.width / 2.f, winSize.height - 95.f });

        auto btnRec = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Record Here", 90, true, "bigFont.fnt", "GJ_button_06.png", 28.f, 0.42f),
            this, menu_selector(FrameMainPopup::onToggleRecord)
        );
        auto btnPlay = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Play Macro", 90, true, "bigFont.fnt", "GJ_button_01.png", 28.f, 0.42f),
            this, menu_selector(FrameMainPopup::onTogglePlay)
        );
        auto btnAnalyze = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Analyze FW", 90, true, "bigFont.fnt", "GJ_button_04.png", 28.f, 0.42f),
            this, menu_selector(FrameMainPopup::onOpenAnalyzer)
        );
        auto btnClear = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Clear", 55, true, "bigFont.fnt", "GJ_button_05.png", 28.f, 0.42f),
            this, menu_selector(FrameMainPopup::onClearMacro)
        );

        ctrlMenu->addChild(btnRec);
        ctrlMenu->addChild(btnPlay);
        ctrlMenu->addChild(btnAnalyze);
        ctrlMenu->addChild(btnClear);
        ctrlMenu->alignItemsHorizontallyWithPadding(6.f);
        m_mainLayer->addChild(ctrlMenu);

        m_speedLbl = CCLabelBMFont::create("", "bigFont.fnt");
        m_speedLbl->setScale(0.40f);
        m_speedLbl->setPosition({ winSize.width / 2.f, winSize.height - 132.f });
        m_speedLbl->setColor({ 130, 255, 165 });
        m_mainLayer->addChild(m_speedLbl);

        auto speedMenu = CCMenu::create();
        speedMenu->setPosition({ winSize.width / 2.f, winSize.height - 158.f });

        const char* speedNames[5] = { "0.25x", "0.5x", "0.75x", "1.0x (Off)", "1.5x" };
        int speedTags[5] = { 25, 50, 75, 100, 150 };
        for (int i = 0; i < 5; ++i) {
            auto spBtn = CCMenuItemSpriteExtra::create(
                ButtonSprite::create(speedNames[i], 58, true, "bigFont.fnt", "GJ_button_02.png", 25.f, 0.38f),
                this, menu_selector(FrameMainPopup::onSetSpeedhack)
            );
            spBtn->setTag(speedTags[i]);
            speedMenu->addChild(spBtn);
        }
        speedMenu->alignItemsHorizontallyWithPadding(5.f);
        m_mainLayer->addChild(speedMenu);

        m_fileInput = geode::TextInput::create(190.f, "Macro Name (e.g. preview_1)");
        m_fileInput->setString(g_mod.macro.name);
        m_fileInput->setPosition({ winSize.width / 2.f, 65.f });
        m_mainLayer->addChild(m_fileInput);

        auto ioMenu = CCMenu::create();
        ioMenu->setPosition({ winSize.width / 2.f, 30.f });

        auto btnSave = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Save / Export", 105, true, "goldFont.fnt", "GJ_button_01.png", 26.f, 0.5f),
            this, menu_selector(FrameMainPopup::onSaveMacro)
        );
        auto btnLoad = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Load / Import", 105, true, "goldFont.fnt", "GJ_button_02.png", 26.f, 0.5f),
            this, menu_selector(FrameMainPopup::onLoadMacro)
        );
        auto btnFolder = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Open Folder", 95, true, "goldFont.fnt", "GJ_button_04.png", 26.f, 0.5f),
            this, menu_selector(FrameMainPopup::onOpenMacrosFolder)
        );

        ioMenu->addChild(btnSave);
        ioMenu->addChild(btnLoad);
        ioMenu->addChild(btnFolder);
        ioMenu->alignItemsHorizontallyWithPadding(8.f);
        m_mainLayer->addChild(ioMenu);

        refreshLabels();
        return true;
    }

    void refreshLabels() {
        std::string status = "STATE: IDLE (HUD Hidden)";
        if (g_mod.isRecording) {
            status = fmt::format("STATE: RECORDING (Start X: {:.1f})", g_mod.macro.startX);
            m_stateInfoLbl->setColor({ 255, 85, 85 });
        } else if (g_mod.isPlaying) {
            status = fmt::format("STATE: PLAY MACRO ON (Sync at X: {:.1f})", g_mod.macro.startX);
            m_stateInfoLbl->setColor({ 90, 255, 130 });
        } else {
            m_stateInfoLbl->setColor({ 230, 230, 230 });
        }
        m_stateInfoLbl->setString(status.c_str());

        int count1F = 0;
        for (const auto& a : g_mod.macro.actions) {
            if (a.down && a.frameWindow == 1) count1F++;
        }

        m_macroSummaryLbl->setString(
            fmt::format("Actions: {} | Start X: {:.1f} | Analyzed: {} (1F: {})",
                g_mod.macro.actions.size(),
                g_mod.macro.startX,
                g_mod.macro.analyzed ? "YES" : "NO",
                count1F
            ).c_str()
        );

        m_speedLbl->setString(
            fmt::format("Preview Speedhack: {:.2f}x ({})",
                g_mod.speedhackValue,
                g_mod.speedhackEnabled ? "ACTIVE" : "NORMAL").c_str()
        );
    }

    void onToggleRecord(CCObject*) {
        auto pl = PlayLayer::get();
        if (!g_mod.isRecording) {
            g_mod.isRecording = true;
            g_mod.isPlaying = false;
            g_mod.isWaitingForSync = false;
            g_mod.isSyncedAndLocked = false;
            g_mod.macro.clear();

            if (pl && pl->m_player1) {
                g_mod.macro.levelID = pl->m_level ? pl->m_level->m_levelID.value() : 0;
                g_mod.macro.startX = pl->m_player1->m_position.x;
                g_mod.macro.startY = pl->m_player1->m_position.y;
                g_mod.macro.startYVel = pl->m_player1->m_yVelocity;
                g_mod.macro.startRot = pl->m_player1->getRotation();
                g_mod.syncBaseTick = g_mod.currentTick;
            }
        } else {
            g_mod.isRecording = false;
        }

        if (pl) {
            static_cast<FramePlayLayer*>(pl)->updatePlayMacroHUD();
        }
        refreshLabels();
    }

    void onTogglePlay(CCObject*) {
        auto pl = PlayLayer::get();
        if (!g_mod.isPlaying) {
            if (g_mod.macro.actions.empty()) {
                FLAlertLayer::create("FrameMmeVjopy", "Macro has no actions! Record or Load a macro first.", "OK")->show();
                return;
            }
            g_mod.isPlaying = true;
            g_mod.isRecording = false;
            g_mod.nextActionIdx = 0;

            if (pl && pl->m_player1) {
                double curX = pl->m_player1->m_position.x;
                if (curX < g_mod.macro.startX - 1.5) {
                    g_mod.isWaitingForSync = true;
                    g_mod.isSyncedAndLocked = false;
                } else {
                    g_mod.isWaitingForSync = false;
                    g_mod.isSyncedAndLocked = true;
                    g_mod.syncBaseTick = g_mod.currentTick;
                }
            }
        } else {
            g_mod.isPlaying = false;
            g_mod.isWaitingForSync = false;
            g_mod.isSyncedAndLocked = false;
        }

        if (pl) {
            static_cast<FramePlayLayer*>(pl)->updatePlayMacroHUD();
        }
        refreshLabels();
    }

    void onOpenAnalyzer(CCObject*) {
        FrameAnalyzerPopup::create()->show();
    }

    void onClearMacro(CCObject*) {
        g_mod.isRecording = false;
        g_mod.isPlaying = false;
        g_mod.isWaitingForSync = false;
        g_mod.isSyncedAndLocked = false;
        g_mod.macro.clear();
        if (auto pl = PlayLayer::get()) {
            static_cast<FramePlayLayer*>(pl)->updatePlayMacroHUD();
        }
        refreshLabels();
    }

    void onSetSpeedhack(CCObject* sender) {
        int tag = sender->getTag();
        if (tag == 100) {
            g_mod.speedhackEnabled = false;
            g_mod.speedhackValue = 1.0f;
        } else {
            g_mod.speedhackEnabled = true;
            g_mod.speedhackValue = (float)tag / 100.0f;
        }
        refreshLabels();
    }

    void onSaveMacro(CCObject*) {
        std::string name = m_fileInput->getString();
        if (name.empty()) name = "macro_1";
        if (g_mod.saveToFile(name)) {
            FLAlertLayer::create(
                "Export Success",
                fmt::format("Macro <cg>{}.json</c> saved!\nActions: <cy>{}</c>\nSync Start X: <cp>{:.1f}</c>",
                    name, g_mod.macro.actions.size(), g_mod.macro.startX),
                "OK"
            )->show();
        } else {
            FLAlertLayer::create("Error", "Failed to write macro file!", "OK")->show();
        }
        refreshLabels();
    }

    void onLoadMacro(CCObject*) {
        std::string name = m_fileInput->getString();
        if (name.empty()) name = "macro_1";
        if (g_mod.loadFromFile(name)) {
            FLAlertLayer::create(
                "Import Success",
                fmt::format("Macro <cg>{}.json</c> loaded!\nActions: <cy>{}</c>\nSync Start X: <cp>{:.1f}</c>",
                    name, g_mod.macro.actions.size(), g_mod.macro.startX),
                "OK"
            )->show();
        } else {
            FLAlertLayer::create("Not Found", fmt::format("Macro '{}.json' not found in macros folder.", name), "OK")->show();
        }
        refreshLabels();
    }

    void onOpenMacrosFolder(CCObject*) {
        file::openFolder(g_mod.getMacrosFolder());
    }

public:
    static FrameMainPopup* create() {
        auto ret = new FrameMainPopup();
        if (ret && ret->initAnchored(380.f, 240.f, "GJ_square01.png")) {
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

class $modify(FramePauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        auto menu = CCMenu::create();
        menu->setPosition({ 46.f, winSize.height / 2.f });
        menu->setZOrder(100);

        auto btnSpr = ButtonSprite::create("FMV", 36, true, "goldFont.fnt", "GJ_button_04.png", 32.f, 0.55f);
        auto btn = CCMenuItemSpriteExtra::create(
            btnSpr,
            this,
            menu_selector(FramePauseLayer::onOpenFrameMod)
        );
        menu->addChild(btn);
        this->addChild(menu);
    }

    void onOpenFrameMod(CCObject*) {
        FrameMainPopup::create()->show();
    }
};
